<?php
namespace App\Models;

use CodeIgniter\Model;

class CrudModel extends Model
{
    // Nombre de la tabla en la base de datos
    protected $table = 'tareas';
    // Clave primaria de la tabla
    protected $primaryKey = 'id_tarea';
    // Campos que se permiten para las operaciones CRUD
    protected $allowedFields = ['descripcion', 'prioridad', 'fecha', 'completada'];

    // Método para listar todas las tareas
    public function listarTareas()
    {
        $query = $this->db->query("SELECT * FROM tareas");
        return $query->getResult(); // Devuelve un arreglo de objetos
    }

    // Método para insertar una nueva tarea
    public function insertar($datos)
    {
        return $this->insert($datos);
    }

    // Método para obtener una tarea específica por ID
    public function obtenerTarea($id_tarea)
    {
        return $this->find($id_tarea);
    }

    // Método para actualizar una tarea
    public function actualizar($data, $id_tarea)
    {
        return $this->update($id_tarea, $data);
    }

    // Método para eliminar una tarea
    public function eliminar($id_tarea)
    {
        return $this->delete($id_tarea);
    }

    // Método para completar una tarea
    public function completarTarea($id_tarea)
    {
        return $this->update($id_tarea, ['completada' => 1]);
    }

    // Método para descompletar una tarea
    public function descompletarTarea($id_tarea)
    {
        return $this->update($id_tarea, ['completada' => 0]);
    }
}