<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

// Ruta para mostrar la vista "listado" con todas las tareas
$routes->get('/', 'CRUD::index');

// Ruta para crear una nueva tarea
$routes->post('crear', 'CRUD::crear');

// Ruta para actualizar una tarea existente
$routes->post('actualizar/(:num)', 'CRUD::actualizar/$1');

// Ruta para eliminar una tarea
$routes->post('eliminar/(:num)', 'CRUD::eliminar/$1');

// Ruta para marcar una tarea como completada
$routes->get('completar/(:num)', 'CRUD::completar/$1'); 

// Ruta para marcar una tarea como no completada
$routes->get('descompletar/(:num)', 'CRUD::descompletar/$1'); 

// Ruta para obtener los detalles de una tarea específica
$routes->get('obtener/(:num)', 'CRUD::obtenerTarea/$1');