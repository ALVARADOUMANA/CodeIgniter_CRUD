<?php

namespace App\Controllers;

use App\Models\CrudModel;
use CodeIgniter\Controller;
class CRUD extends Controller
{
    public function index()
    {
        $crudModel = new CrudModel();
        $data['datos'] = $crudModel->listarTareas();
        
        return view('listado', $data); // Asegúrate de que el nombre de la vista es listado
    }

    public function crear()
    {
        try {
            $crudModel = new CrudModel();
            $data = [
                'descripcion' => $this->request->getPost('descripcion'),
                'prioridad' => $this->request->getPost('prioridad'),
                'fecha' => $this->request->getPost('fecha'),
                'completada' => 0,
            ];
            $crudModel->insertar($data);
            return $this->response->setJSON(['success' => true, 'message' => 'Tarea creada correctamente']);
        } catch (\Exception $e) {
            return $this->response->setStatusCode(500)->setJSON(['success' => false, 'error' => 'Error al crear la tarea: ' . $e->getMessage()]);
        }
    }
    public function obtenerTarea($id_tarea)
    {
        try {
            $crudModel = new CrudModel();
            $tarea = $crudModel->obtenerTarea($id_tarea);
    
            if ($tarea) {
                return $this->response->setJSON($tarea);
            } else {
                return $this->response->setStatusCode(404)->setBody('Tarea no encontrada');
            }
        } catch (\Exception $e) {
            return $this->response->setStatusCode(500)->setBody('Error al obtener la tarea: ' . $e->getMessage());
        }
    }

    public function actualizar($id_tarea)
    {
        try {
            $crudModel = new CrudModel();
            
            // Obtener el cuerpo de la solicitud como JSON
            $json = $this->request->getJSON();

            // Si no se reciben datos JSON, intenta obtener los datos como array
            $data = $json ? (array) $json : $this->request->getPost();

            // Verificar si los campos están vacíos y eliminarlos del array
            $data = array_filter($data, function($value) {
                return $value !== '';
            });

            // Verificar si la fecha está presente y no es cero
            if (isset($data['fecha']) && $data['fecha'] == '0000-00-00 00:00:00') {
                unset($data['fecha']);
            }

            // Verificar si la tarea se marca como completada o no
            if (isset($data['completada'])) {
                $data['completada'] = 1; // Marcar como completada
            } else {
                $data['completada'] = 0; // Marcar como no completada
            }

            $crudModel->actualizar($data, $id_tarea);
            return $this->response->setStatusCode(200)->setBody('Tarea actualizada correctamente');
        } catch (\Exception $e) {
            return $this->response->setStatusCode(500)->setBody('Error al actualizar la tarea: ' . $e->getMessage());
        }
    }

    public function completar($id_tarea)
    {
        try {
            $crudModel = new CrudModel();
            $crudModel->completarTarea($id_tarea); // Llama al método en el modelo para completar la tarea
            return $this->response->setStatusCode(200)->setBody('Tarea completada correctamente');
        } catch (\Exception $e) {
            return $this->response->setStatusCode(500)->setBody('Error al completar la tarea: ' . $e->getMessage());
        }
    }

    public function descompletar($id_tarea)
    {
        try {
            $crudModel = new CrudModel();
            $crudModel->descompletarTarea($id_tarea); // Llama al método en el modelo para descompletar la tarea
            return $this->response->setStatusCode(200)->setBody('Tarea descompletada correctamente');
        } catch (\Exception $e) {
            return $this->response->setStatusCode(500)->setBody('Error al descompletar la tarea: ' . $e->getMessage());
        }
    }

    public function eliminar($id_tarea)
    {
        try {
            $crudModel = new CrudModel();
            $crudModel->eliminar($id_tarea);
            return $this->response->setStatusCode(200)->setBody('Tarea eliminada correctamente');
        } catch (\Exception $e) {
            return $this->response->setStatusCode(500)->setBody('Error al eliminar la tarea: ' . $e->getMessage());
        }
    }
}