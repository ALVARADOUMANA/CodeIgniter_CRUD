<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css"
        integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <title>CRUD</title>
</head>

<body class="bg-light">

    <div class="container my-5">
        <div class="card shadow-sm">
            <div class="card-header bg-info  text-white">
                <h2>Crear Tareas</h2>
            </div>
            <div class="card-body">
                <form id="crear-tarea-form" method="POST" action="<?php echo base_url() . '/crear' ?>">
                    <label for="descripcion">Descripcion</label>
                    <input type="text" name="descripcion" id="descripcion" class="form-control">
                    <label for="prioridad">Prioridad</label>
                    <select id="prioridad" name="prioridad" class="form-control">
                        <option value="baja">Baja</option>
                        <option value="media">Media</option>
                        <option value="alta">Alta</option>
                    </select>
                    <label for="fecha">Fecha</label>
                    <input type="datetime-local" name="fecha" id="fecha" class="form-control">
                    <br>
                    <button class="btn btn-primary">Guardar</button>
                </form>
            </div>
        </div>
    </div>
    <hr>
    <div class="container my-5">
        <div class="card shadow-sm">
            <div class="card-header bg-info   text-white">
                <h2>Ver Tareas</h2>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover table-bordered">
                        <tr>
                            <th>Completar</th>
                            <th>Descripcion</th>
                            <th>Prioridad</th>
                            <th>Fecha</th>
                            <th>Acción</th>
                        </tr>
                        <?php foreach ($datos as $key): ?>
                            <tr>
                                <td>
                                    <div class="d-flex justify-content-center">
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input complete-checkbox" type="checkbox"
                                                data-task-id="<?php echo $key->id_tarea ?>" <?php echo isset($key->completada) && $key->completada ? 'checked' : ''; ?>
                                                style="width: 1.5rem; height: 1.5rem;">
                                        </div>
                                    </div>
                                </td>
                                <td><?php echo $key->descripcion ?></td>
                                <td><?php echo $key->prioridad ?></td>
                                <td><?php echo $key->fecha ?></td>
                                <td>
                                    <button class="btn btn-primary btn-sm btn-ver-editar" data-toggle="modal"
                                        data-target="#taskModal" data-task-id="<?php echo $key->id_tarea ?>">
                                        Ver/Editar
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>

                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="taskModal" tabindex="-1" role="dialog" aria-labelledby="taskModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="taskModalLabel">Detalles de la tarea</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="taskForm">
                        <input type="hidden" id="taskId">
                        <div class="form-group">
                            <label for="descripcion">Descripción</label>
                            <input type="text" class="form-control" id="modalDescripcion" name="descripcion">
                        </div>
                        <div class="form-group">
                            <label for="prioridad">Prioridad</label>
                            <select class="form-control" id="modalPrioridad" name="prioridad">
                                <option value="baja">Baja</option>
                                <option value="media">Media</option>
                                <option value="alta">Alta</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="fecha">Fecha</label>
                            <input type="datetime-local" class="form-control" id="modalFecha" name="fecha">
                            <span id="fecha-error" class="error-message"></span>

                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" id="deleteTask">Eliminar</button><button type="button"
                        class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                    <button type="button" class="btn btn-primary" id="saveTask">Guardar</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
        integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js"
        integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js"
        integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script type="text/javascript">
        $(document).ready(function () {
            $('#crear-tarea-form').submit(async function (event) {
                event.preventDefault(); // Evitar el envío del formulario

                const formData = $(this).serialize(); // Obtener los datos del formulario

                try {
                    const response = await fetch('<?php echo base_url() ?>/crear', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded'
                        },
                        body: formData
                    });

                    const data = await response.json();

                    if (data.success) {
                        await Swal.fire({
                            icon: 'success',
                            title: 'Éxito',
                            text: data.message,
                            confirmButtonText: 'Aceptar'
                        });
                        $(this)[0].reset(); // Resetear el formulario
                        location.reload(); // Recargar la página
                    } else {
                        throw new Error(data.error);
                    }
                } catch (error) {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: 'Error al crear la tarea: ' + error,
                        confirmButtonText: 'Aceptar'
                    });
                }

            });
            // Manejo de clic en checkboxes
            $('.complete-checkbox').change(function () {
                var taskId = $(this).data('task-id');
                var isChecked = $(this).prop('checked');

                if (isChecked) {
                    completarTarea(taskId);
                } else {
                    descompletarTarea(taskId);
                }
            });

            // Manejo de clic en botón "Ver/Editar"
            $(document).on('click', '.btn-ver-editar', function () {
                var taskId = $(this).data('task-id');
                obtenerTarea(taskId);
                $('#taskModal').modal('show'); // Mostrar el modal al hacer clic en Ver/Editar
            });

            // Manejo de clic en botón "Guardar"
            $('#saveTask').click(function () {
                var taskId = $('#taskId').val();
                var descripcion = $('#modalDescripcion').val();
                var prioridad = $('#modalPrioridad').val();
                var fecha = $('#modalFecha').val();

                actualizarTarea(taskId, descripcion, prioridad, fecha);
            });

            // Manejo de clic en botón "Eliminar"
            $('#deleteTask').click(function () {
                var taskId = $('#taskId').val();
                eliminarTarea(taskId);
            });

            function mostrarAlerta(mensaje, tipo, titulo = '') {
                Swal.fire({
                    icon: tipo,
                    title: titulo || (tipo === 'success' ? 'Éxito' : 'Error'),
                    text: mensaje,
                    confirmButtonText: 'Aceptar'
                });
            }

            function obtenerTarea(taskId) {
                fetch('<?php echo base_url() ?>/obtener/' + taskId)
                    .then(response => {
                        if (!response.ok) {
                            throw new Error('Error al obtener la tarea');
                        }
                        return response.json();
                    })
                    .then(data => {
                        $('#taskId').val(data.id_tarea);
                        $('#modalDescripcion').val(data.descripcion);
                        $('#modalPrioridad').val(data.prioridad);
                        $('#modalFecha').val(data.fecha);
                    })
                    .catch(error => {
                        mostrarAlerta('Error al obtener la tarea: ' + error, 'error');
                    });
            }

            async function actualizarTarea(taskId, descripcion, prioridad, fecha) {
                const data = {
                    descripcion: descripcion,
                    prioridad: prioridad,
                    fecha: fecha
                };

                try {
                    const response = await fetch('<?php echo base_url() ?>/actualizar/' + taskId, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify(data)
                    });

                    if (response.ok) {
                        await Swal.fire({
                            icon: 'success',
                            title: 'Éxito',
                            text: 'Tarea actualizada correctamente',
                            confirmButtonText: 'Aceptar'
                        });
                        $('#taskModal').modal('hide');
                        location.reload();
                    } else {
                        const mensaje = await response.text();
                        throw new Error(mensaje);
                    }
                } catch (error) {
                    await Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: 'Error al actualizar la tarea: ' + error,
                        confirmButtonText: 'Aceptar'
                    });
                }
            }

            async function eliminarTarea(taskId) {
                try {
                    const result = await Swal.fire({
                        title: '¿Estás seguro?',
                        text: 'Esta acción no se puede deshacer',
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonText: 'Sí, eliminar',
                        cancelButtonText: 'Cancelar'
                    });

                    if (result.isConfirmed) {
                        const response = await fetch('<?php echo base_url() ?>/eliminar/' + taskId, {
                            method: 'POST'
                        });

                        if (response.ok) {
                            await Swal.fire({
                                icon: 'success',
                                title: 'Éxito',
                                text: 'Tarea eliminada correctamente',
                                confirmButtonText: 'Aceptar'
                            });
                            $('#taskModal').modal('hide');
                            location.reload();
                        } else {
                            const mensaje = await response.text();
                            throw new Error(mensaje);
                        }
                    } else if (result.dismiss === Swal.DismissReason.cancel) {
                        await Swal.fire({
                            icon: 'info',
                            title: 'Cancelado',
                            text: 'La tarea no ha sido eliminada',
                            confirmButtonText: 'Aceptar'
                        });
                    }
                } catch (error) {
                    await Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: 'Error al eliminar la tarea: ' + error,
                        confirmButtonText: 'Aceptar'
                    });
                }
            }


            function completarTarea(taskId) {
                fetch('<?php echo base_url() ?>/completar/' + taskId, {
                    method: 'GET'
                })
                    .then(response => {
                        if (response.ok) {
                            mostrarAlerta('Tarea completada correctamente', 'success');
                        } else {
                            return response.text().then(mensaje => {
                                throw new Error(mensaje);
                            });
                        }
                    })
                    .catch(error => {
                        mostrarAlerta('Error al completar la tarea: ' + error, 'error');
                    });
            }

            function descompletarTarea(taskId) {
                fetch('<?php echo base_url() ?>/descompletar/' + taskId, {
                    method: 'GET'
                })
                    .then(response => {
                        if (response.ok) {
                            mostrarAlerta('Tarea descompletada correctamente', 'success');
                        } else {
                            return response.text().then(mensaje => {
                                throw new Error(mensaje);
                            });
                        }
                    })
                    .catch(error => {
                        mostrarAlerta('Error al descompletar la tarea: ' + error, 'error');
                    });
            }
        });
    </script>
</body>

</html>